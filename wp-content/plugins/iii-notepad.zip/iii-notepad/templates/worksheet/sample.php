<?php
/**
 * Created by vagrant.
 * User: vagrant
 * Date: 5/17/2020
 * Time: 10:52 PM
 */

?>
<div class="ws-sample hidden">
	<div class="ws-sample-inner">
		<span class="sample-notice">
			<?php echo esc_html__('This is sample worksheet', 'iii-notepad'); ?>
		</span>
		<span class="sample-close">
			<img src="<?php echo III_NOTEPAD_PLUGIN_DIR_URL; ?>assets/images/worksheet/01_icon_Sample_Close.png" />
		</span>
	</div>
</div>
