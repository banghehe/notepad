<?php
/**
 * Created by vagrant.
 * User: vagrant
 * Date: 2/17/2020
 * Time: 1:44 PM
 */

?>
<div class="ws-preview hidden">
	<div class="ws-preview-inner"></div>
</div>
