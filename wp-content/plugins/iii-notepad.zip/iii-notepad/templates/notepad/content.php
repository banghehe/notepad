<?php
/**
 * Created by vagrant.
 * User: vagrant
 * Date: 2/14/2020
 * Time: 10:18 AM
 */

?>

<div class="col-8 main-content main-notepad">
	<div id="cursors">

	</div>
	<div id="panel" class="panel">

	</div>
	<div id="divrubber" title="drag to erase with checkbox signed" alt="drag to erase with checkbox signed">
		<div id="controlrubber" class="css-img-erase"></div>
	</div>
	<div id="videoChat" class="hidden" style="display: block;">
		<div id="closeVideo"></div>
		<div id="loading"></div>
		<div id="video" style="width: 100%; height: 100%"></div>
	</div>
	<div id="yotubeVideo" class="hidden"></div>
</div>